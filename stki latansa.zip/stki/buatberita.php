<div class="container">
<?php
include 'index.php';
include 'koneksi.php';
?>
<form method='POST'>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Judul Berita</label>
  <input type="text" class="form-control" name='judul' id="exampleFormControlInput1" placeholder="Judul Berita">
</div>
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Isi Berita</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" name='isi' rows="3"></textarea>
</div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">URL</label>
  <input type="text" class="form-control" name='url' id="exampleFormControlInput1" placeholder="URL">
</div>
<div class="mb-3">
  <button type="submit" class="btn btn-primary mb-3" name="BtnAdd">Save</button>
</div>
		  
</form>
<?php
if(isset($_POST['BtnAdd'])){ 

$judul1 = $_POST['judul'];
$isi1 = $_POST['isi'];
$url1 = $_POST['url'];
$id1 = str_replace(" ", "_", $judul1); 

		$query = "INSERT INTO berita VALUES ('$id1','$judul1','$isi1','$url1')"; 
		$insert_query  = mysqli_query($koneksi,$query);
}

?>