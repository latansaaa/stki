<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.css">
  


   <title>Sistem Temu Kembali</title>
  </head>
  <body>
  <div class="container">
<h2 align=center>Sistem Temu Kembali Informasi</h2>
<nav class="navbar navbar-expand-lg navbar-light bg-info center">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse center" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="koneksi.php">Koneksi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="buatberita.php">Buat Dokumen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="lihatberita.php">Lihat Dokumen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="lowercase.php">Lower Case Dokumen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="hapustandabaca.php">Hapus Tanda Baca</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tokenisasi.php">Tokenisasi Kata</a>
        </li>
        </ul>
    </div>
  </div>
</nav>
<div class="container" >
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  
       <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
<ul class="navbar-nav">
      <li class="nav-item">
          <a class="nav-link" href="datastopword.php">Data Stopword</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="prosesstopword.php">Proses Stopword</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="prosesstemming.php">Proses Stemming</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tf.php">Term Frequency</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="idf.php">Invers Document Frequency</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="tfidf.php">TF.IDF</a>
        </li>
</ul>
    </div>
  </div>
</nav>
<hr/>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
  </body>

</html>