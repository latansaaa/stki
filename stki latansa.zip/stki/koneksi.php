<?php
//include 'index.php';

$host  = "localhost";
$username  = "root";
$password  = "";
$database  = "stki";
$koneksi  = mysqli_connect($host,  $username,  $password, $database);
$pilihdatabase  = mysqli_select_db($koneksi, "stki");
if  ($pilihdatabase) echo "<h5>Koneksi Tersambung <text class='text-primary'>Faizal falatansa 16.01.53.0126</text></h5><hr>";
else echo "Koneksi Gagal ";
?>