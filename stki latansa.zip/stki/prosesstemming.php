<div class="container">
<table class="table" id="dataTables">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">No</th>
      <th scope="col">Kode</th>
      <th scope="col">Kata</th>
      <th scope="col">Frek</th>
    </tr>
  </thead>
  <tbody>
  <?php
include "index.php";
include "koneksi.php";
require_once __DIR__ . '/vendor/autoload.php';
$stemmerFactory = new \Sastrawi\Stemmer\StemmerFactory();
$stemmer  = $stemmerFactory->createStemmer();

$query = "SELECT * FROM token";
$result = mysqli_query($koneksi,$query);
while($row = mysqli_fetch_array($result)){  
    $names[] = $row['kata']; 
} 

$sentence = implode(" ", $names); 
$output = $stemmer->stem($sentence);

$lines = preg_split("/[\s]+/", $output);
$baris = preg_split("/[\s]+/", $sentence);

foreach ($baris as $index => $value)
{
    $query = "UPDATE token SET kata='$lines[$index]' WHERE kata='$baris[$index]'";
	$result = mysqli_query($koneksi,$query);
}

$query = "SELECT * FROM token";
$result = mysqli_query($koneksi,$query);
$no=1;
while($row = mysqli_fetch_array($result)){  
$id1 = $row['id'];
$no1 = $row['no'];
$kode1 = $row['kode'];
$kata1 = $row['kata'];
$freq1 = $row['freq'];
echo "<td><font color=blue></font>" . " $row[id] " . "<br></td>"; 
echo "<td><font color=blue></font>" . " $row[no] " . "<br></td>"; 
echo "<td><font color=blue></font>" . " $row[kode] " . "<br></td>"; 
echo "<td><font color=blue></font>" . " $row[kata] " . "<br></td>"; 
echo "<td><font color=blue></font>" . " $row[freq] " . "<br></td>"; 
echo "</tr>";
$no++;
}
?>
  </tbody>
  </table>
</div>


